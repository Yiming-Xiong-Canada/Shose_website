<?php
    include 'database.php';
 
    $shoesName = trim(@$_POST['shoesName']);
    $p1 =  floatval( @$_POST['p1'] );
    $p2  = floatval( @$_POST['p2'] );
    $rating = intval( @$_POST['rating'] );
    $sort  = intval( @$_POST['sort'] );

    //print_r( $_POST );

    $conn = OpenCon();
     
    $sql = "SELECT * FROM products WHERE 1=1 ";
    if( $shoesName != ''){
       $sql .= " and  s_name LIKE '%" . $shoesName . "%' ";
    }
    if( $p1 >= 0 && $p2 >= 0 ){
       $sql .= " and $p1 < s_price and s_price < $p2 ";
    }
    if( $rating > 0 ){
      $sql .= " and s_rating = $rating ";
    }
    if( $sort == '0'){
      $sql .= " order by s_price asc ";
       
    }
    elseif( $sort == '1'){
      $sql .= " order by s_price desc ";
    }
    //echo $sql;

    $result = $conn->query( $sql);
    
    $arr = array();

    
   while($row = $result->fetch_assoc( )){
      $arr[] = $row;
   }
   
   CloseCon($conn);

   header('content-type: application/json');
   echo json_encode( $arr );

