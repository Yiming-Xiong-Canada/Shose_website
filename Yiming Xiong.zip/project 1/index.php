﻿ <?php
    include 'database.php';
    $conn = OpenCon();
    CloseCon($conn);
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Landing Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet"  href="css/submenu.css">
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="logo" href="#">  <img src="images/logo.jpg"width="175" height="50"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.html">HOME</a></li>
		<li><a href="category.html">CATEGORIES</a></li>
        <li><a href="#tour">Sign Up</a></li>
        <li><a href="#contact">View Cart</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">MORE
            <span class="caret"></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="#">Merchandise</a></li>
            <li><a href="#">Extras</a></li>
            <li><a href="#">Media</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center">
  <h1>Sneaker bear</h1>
  <p>You can find every sneaker in the world</p>
  <form class="form-inline" action = "search.php" method = "POST">
    <div class="input-group">
      <input type="text" class="form-control" name = 'shoesName' id="shoesName" size="50" placeholder="shoes name" required>
      <div class="input-group-btn">
        <button type="submit" class="btn btn-danger"  >Search</button>
      </div>
    </div>
  </form>
</div>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="images/sneaker1.jpg" alt="New York" width="1200" height="700">
        <div class="carousel-caption">
          <h3>NIKE AIR MAX 270 REACT</h3>
          <p>Inspired by the colors and lights of an urban landscape, the Nike Air Max 270 React uses lightweight, layered materials to create a modern style that looks as good as it feels.</p>
        </div>      
      </div>

      <div class="item">
        <img src="images/sneaker2.jpg" alt="Chicago" width="1200" height="700">
        <div class="carousel-caption">
          <h3>Sneaker bear 1</h3>
          <p>Sneaker Bear's first pair of high-top sneakers, with straps at the upper and the glowing sole, show the personality of the shoes.</p>
        </div>      
      </div>
    
      <div class="item">
        <img src="images/sneaker3.jpg" alt="Los Angeles" width="1200" height="700">
        <div class="carousel-caption">
          <h3>Nike Dunk SB High Mcrad</h3>
          <p>Nike SB switches up their stance in terms of their design approach for Black History Month. The shoe pays tribute to Chuck Treece, one of the first African American skaters to appear on the cover of Thrasher magazine in 1984. The sneaker’s color scheme represents the design of the cover image, while also referencing his 80s rock band McRad, whose logo appears on the tongue. 
		     The insoles are lined with a graphic of Treece skating, and “84” is embellished on the toe as a final call out to his cover.</p>
        </div>      
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>

</div>
<script src="js/search.js"></script>
</body>
</html>