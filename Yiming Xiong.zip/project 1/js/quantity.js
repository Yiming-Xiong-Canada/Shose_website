
$("button").on("click", function (ev) {
    var currentQty = $('input[name="quantity"]').val();
    var qtyDirection = $(this).data("direction");
    var newQty = 0;

    if (qtyDirection == "1") {
        newQty = parseInt(currentQty) + 1;
    }
    else if (qtyDirection == "-1") {
        newQty = parseInt(currentQty) - 1;
    }

    // make decrement disabled at 1
    if (newQty == 1) {
        $(".decrement-quantity").attr("disabled", "disabled");
    }

    // remove disabled attribute on subtract
    if (newQty > 1) {
        $(".decrement-quantity").removeAttr("disabled");
    }

    if (newQty > 0) {
        newQty = newQty.toString();
        $('input[name="quantity"]').val(newQty);
    }
    else {
        $('input[name="quantity"]').val("1");
    }
});


function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.innerHTML = "Read less";
        moreText.style.display = "inline";
    }
}
