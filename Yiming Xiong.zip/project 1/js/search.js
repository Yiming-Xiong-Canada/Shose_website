
var q =new Object();
q['sort'] ='';

//this function for the search bar of index page depends on user's input
 
 
 
 
 
//this function for load the data of product
function loadData(  ) {

     //invoke the value of p1
    var p1 = document.getElementById("p1").value;
    //invoke the value of p2
    var p2 = document.getElementById("p2").value;
    //inovke thevalue of rating filter
    var myRange = document.getElementById("myRange").value;

    //invoke the shoesname
     shoesName = document.getElementById("shoesName").value;
    //filter the result by name
     q['shoesName'] = shoesName;
    q['p1'] = p1;
    q['p2'] = p2;
    q['rating'] = myRange;


    console.log('query', q );

    
    $.post('search_ajax.php',q,function(r){
        //console.log( r );
       // var j = JSON.parse( r );
        render( r );
    }) ;
  
}


function render(datas){
      //initial the content area in html
    document.getElementById("boxs").innerHTML = "";
    
    for (var i = 0; i < datas.length; i++) {
        var str = '';
        for (var j = 0; j < 5; j++) {
            if (j < datas[i].s_rating) {
                str += '<span class="fa fa-star checked"></span>';
            } else {
                str += '<span class="fa fa-star "></span>';
            }
        }
    // this is the template literals of product which display in the result page
    // the $ for indicated the expression, display the content which user choose
        document.getElementById("boxs").innerHTML += `<div class="col-sm-4">
            <div class="thumbnail">
            <a href="product.php?id=${datas[i].s_id}"><img src="${datas[i].s_img}"></a>
              <p><strong><h4>${datas[i].s_name}</h4></strong></p>
              <p style="color:red">$${datas[i].s_price}</p>
              <p>
              ${str}
              <a>63</a>
              </p>
              <button class="btn"><a href="product.php?id=${datas[i].s_id}">Buy Now</a></button>
            </div>
           </div>`

    }
}
//this function for the price range filter
function fmyRange() {
   

 
//return the data to nowgoods array
    loadData( );
}



//this function for price sort button
function filterSelection(t) {
     q['sort'] =t;
     loadData( );
}
//this function for filter the result by name and load data in nowGoods array
function filterByName() {
    //invoke the name value
    //var name = getQueryVariable("name");
    //set the result value in the nowgoods value
  //  document.getElementById("shoesName").value = name;
    //use function loaddata to display the result
    loadData( );
}

//get url parameter value
function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) { return pair[1]; }
    }
    return (false);
}


//this function for rearch bar in result page to filter the products by user's input
function resultgo() {
    
    //load data in now goods array
     loadData( );
}

$(function(){

    filterByName() ;

});