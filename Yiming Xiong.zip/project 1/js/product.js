// create an array of products with every detials in product page
 
// set a new variable num = 1 to be the least quantity.
var num = 1;

// when quantity added, price also
function add() {
    //when user click +, num add one
	num++;
	//get the numbers value from html
    document.getElementById("numbers").value = num;
	//change the prices when number changed
    document.getElementById("prices").innerHTML = "$" + num * good.s_price;
}
// when quantity reduce, price also
function reduce() {
    // quantity can not be less than one, popup alert
	if (num == 1) {
        alert("It can't be less");
    }
	// if more than one, when user click '-', number minus one
    else {
        num--;
    }
	//get the numbers value from html
    document.getElementById("numbers").value = num;
	//change the prices when number changed
    document.getElementById("prices").innerHTML = "$" + num * good.s_price;
}

//get the id
//var id = getQueryVariable('id');
//set variable good equals the good user choose
//var good = goods.filter(o => o.id == id)[0];

//load product's image
document.getElementById("img").src = good.s_img;
//load product's name
document.getElementById("name").innerHTML = good.s_name;
//load product's price
document.getElementById("prices").innerHTML = "$" + good.s_price;
//get the rating of the product
var rate = document.getElementsByName("rate");

$("#star"+good.s_rating).click();