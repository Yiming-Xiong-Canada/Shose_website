﻿<?php
$id = intval( $_GET['id']);

include 'database.php';
 $conn = OpenCon();
     
$sql = "SELECT * FROM products WHERE s_id= " . $id ;


$result = $conn->query( $sql);
    
 $row = $result->fetch_assoc( );
 //print_r( $row );

CloseCon($conn);

?><!DOCTYPE html>
<html lang="en">
<html>
<head>
    <title>Product page</title>
    <link rel="stylesheet" href="css/productstyle.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/submenu.css">
    <link rel="stylesheet" href="css/quantity.css">
    <link rel="stylesheet" href="css/rating.css">
    <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="logo" href="#">  <img src="images/logo.jpg" width="175" height="50"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="category.html">CATEGORIES</a></li>
                    <li><a href="#tour">Sign Up</a></li>
                    <li><a href="#contact">View Cart</a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            MORE
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Merchandise</a></li>
                            <li><a href="#">Extras</a></li>
                            <li><a href="#">Media</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="jumbotron text-center">
        <p> </p>
        <p>You can find every sneaker in the world</p>
        <form class="form-inline">
            <div class="input-group">
                <input type="shoes" class="form-control" size="50" placeholder="shoes name" required>
                <div class="input-group-btn">
                    <button type="button" class="btn btn-danger"><a href="results.html">Search</a></button>
                </div>
            </div>
        </form>
    </div>

    <main class="container">

        <!-- Left Column / AIR JORDAN Image -->
        <div class="leftcol">
            <img id="img" src="<?php echo $row['s_img']; ?>" width="650" height="500" border="0" alt="" />
        </div>

        <!-- Right Column -->
        <div class="right-column">
            <!-- Product Description -->
            <div class="product-description">
                <a>AIR JORDAN</a>
                <h2 id="name"><?php echo $row['s_name']; ?></h2>
                <p>
                    Nike SB switches up their stance in terms of their design approach for Black History Month. The shoe pays tribute to Chuck Treece, one of the first African American skaters to appear on the cover of Thrasher magazine in 1984.
                    <span id="dots">...</span><span id="more">
                        The sneaker’s color scheme represents the design of the cover image, while also referencing his 80s rock band McRad, whose logo appears on the tongue.
                        The insoles are lined with a graphic of Treece skating, and “84” is embellished on the toe as a final call out to his cover.
                    </span>
                </p><button onclick="myFunction()" id="myBtn">Read more</button>

                <script>
                    function myFunction() {
                        var dots = document.getElementById("dots");
                        var moreText = document.getElementById("more");
                        var btnText = document.getElementById("myBtn");

                        if (dots.style.display === "none") {
                            dots.style.display = "inline";
                            btnText.innerHTML = "Read more";
                            moreText.style.display = "none";
                        } else {
                            dots.style.display = "none";
                            btnText.innerHTML = "Read less";
                            moreText.style.display = "inline";
                        }
                    }
                </script>
            </div>

            <div class="product-quantity">
                <h3>Quantity</h3>
                <input data-min="1" data-max="0" type="text" name="quantity" value="1" readonly="true" id="numbers"><div class="quantity-selectors-container">
                    <div class="quantity-selectors">
                        <button type="button" class="increment-quantity" aria-label="Add one" data-direction="1" onclick="add()"><span>&#43;</span></button>
                        <button type="button" class="decrement-quantity" aria-label="Subtract one" data-direction="-1" onclick="reduce()"><span>&#8722;</span></button>
                    </div>
                </div>
            </div>
            <br />

            <div class="rate">
                <input type="radio" id="star5" name="rate" value="5" />
                <label for="star5" title="text">5 stars</label>
                <input type="radio" id="star4" name="rate" value="4" />
                <label for="star4" title="text">4 stars</label>
                <input type="radio" id="star3" name="rate" value="3" />
                <label for="star3" title="text">3 stars</label>
                <input type="radio" id="star2" name="rate" value="2" />
                <label for="star2" title="text">2 stars</label>
                <input type="radio" id="star1" name="rate" value="1" />
                <label for="star1" title="text">1 star</label>
            </div>
            <!-- Product Pricing -->
            <div class="product-price">
                <br />
                <p style="color:red" id="prices">$<?php echo $row['s_price']; ?></p>

            </div>
            <a href="#" class="cart-btn">Add to cart</a>
            <a href="#">Need some help?</a>
        </div>
        <script type="text/javascript">
            
            var good = <?php echo json_encode( $row ); ?>;
        </script>
        <script  src="js/product.js"></script>

    </main>
</body>
</html>
