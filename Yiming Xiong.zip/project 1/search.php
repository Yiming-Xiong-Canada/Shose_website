<?php
    include 'database.php';
 
    $shoesName = trim(@$_POST['shoesName']);
    $p1 =  floatval( @$_POST['p1'] );
    $p2  = floatval( @$_POST['p2'] );
    $rating = intval( @$_POST['rating'] );
    $sort  = intval( @$_POST['sort'] );

    //print_r( $_POST );

    $conn = OpenCon();
     
    $sql = "SELECT * FROM products WHERE 1=1 ";
    if( $shoesName != ''){
       $sql .= " and  s_name LIKE '%" . $shoesName . "%' ";
    }
    if( $p1 >= 0 && $p2 > 0 ){
       $sql .= " and $p1 < s_price and s_price < $p2 ";
    }
    if( $rating > 0 ){
      $sql .= " and s_rating = $rating ";
    }
    if( $sort == '0'){
      $sql .= " order by s_price asc ";
       
    }
    elseif( $sort == '1'){
      $sql .= " order by s_price desc ";
    }
    //echo $sql;

    $result = $conn->query( $sql);
    
    $arr = array();

    
   while($row = $result->fetch_assoc( )){
      $arr[] = $row;
   }
   
   CloseCon($conn);


function rt($r){
  $x = '';
  for ($j = 0; $j < 5; $j++) {
            if ($j < $r) {
                $x .= '<span class="fa fa-star checked"></span>';
            } else {
                $x .= '<span class="fa fa-star "></span>';
            }
        }
        return $x;
}
   //header('content-type: application/json');
  // echo json_encode( $arr );
//echo $sql;

?><!DOCTYPE html>
<html lang="en">
<html>
<head>
    <title>Search Results page</title>
    <link rel="stylesheet" href="css/resultsstyle.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/submenu.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="logo" href="#">  <img src="images/logo.jpg" width="175" height="50"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="category.html">CATEGORIES</a></li>
                    <li><a href="#tour">Sign Up</a></li>
                    <li><a href="#contact">View Cart</a></li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            MORE
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Merchandise</a></li>
                            <li><a href="#">Extras</a></li>
                            <li><a href="#">Media</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="jumbotron text-center">
        <p> </p>
        <p>You can find every sneaker in the world</p>
        <form class="form-inline" action="search.php" method="post">
            <div class="input-group">
                <input type="text" class="form-control" id="shoesName" name="shoesName" size="50" placeholder="shoes name" value="<?php echo @$_POST['shoesName']; ?>" required onkeyup="resultgo()" >
                <div class="input-group-btn">
                    <button type="submit" class="btn btn-danger"  >Search</button>
                </div>
            </div>
        </form>
    </div>


    <form action="" class="rozetka-price-form">
        <section class="price-section">
            <div class="price-filter">
                <h2 class="price-title">Choose the price range you want</h2>
                <div class="price-filters">
                    <label><input type="text" id="p1" value="0"></label>
                    <span> -- </span>
                    <label><input type="text" id="p2" value="500"></label>
                    <span>CAD</span>
                    <input type="button" onclick="fmyRange()" value="OK" />
                </div>

            </div>
        </section>
        <div class="slidecontainer">
            <h5>Rating filter</h5>
            <input type="range" min="0" max="5" value="0" class="slider" onchange="fmyRange()" id="myRange">
            <p>Star: <span id="demo"></span></p>
        </div>
        <input type="button" class="sort-btn" onclick="filterSelection('0')" value="sort by price from lowest" />
        <input type="button" class="sort-btn" onclick="filterSelection('1')" value="sort by price from highest" />

    </form>



    <script>
        var slider = document.getElementById("myRange");
        var output = document.getElementById("demo");
        output.innerHTML = slider.value;

        slider.oninput = function () {
            output.innerHTML = this.value;
        }
    </script>


    <div id="container">
        <div class="row text-center" id="boxs">
          <?php foreach( $arr as $r ): ?>
              <div class="col-sm-4">
            <div class="thumbnail">
            <a href="product.php?id=<?php echo $r['s_id']; ?>"><img src="<?php echo $r['s_img']; ?>"></a>
              <p><strong><h4><?php echo $r['s_name']; ?></h4></strong></p>
              <p style="color:red">$<?php echo $r['s_price']; ?></p>
              <p>
              <?php echo rt( $r['s_rating'] ); ?>
              <a>63</a>
              </p>
              <button class="btn"><a href="product.php?id=<?php echo $r['s_id']; ?>">Buy Now</a></button>
            </div>
           </div> 

          <?php endforeach; ?>
        </div>
    </div>
        <script src="js/jquery-3.6.0.min.js"></script>
       <script type="text/javascript">
         
       var goods =  <?php echo json_encode( $arr ); ?>;
       </script>
    <script src="js/search.js"></script>
</body>
</html>
